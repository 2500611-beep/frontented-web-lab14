// Name: Laraib
// Reg No: 2500611

import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { toggleWish, selectWishIds } from '../store/wishlistSlice';
import { addToCart, selectCartItems } from '../store/cartSlice';
import products from '../data/products';

function ProductDetailPage() {
  const { id } = useParams();
  const dispatch = useDispatch();
  const wishIds = useSelector(selectWishIds);
  const cartItems = useSelector(selectCartItems);

  const product = products.find((p) => p.id === Number(id));

  if (!product) {
    return (
      <div style={{ padding: '24px' }}>
        <h2>Product not found</h2>
        <Link to="/">Back to Home</Link>
      </div>
    );
  }

  const isWished = wishIds.includes(product.id);
  const cartItem = cartItems.find((i) => i.id === product.id);

  return (
    <div style={{ padding: '24px', maxWidth: '600px' }}>
      <Link to="/" style={{ display: 'inline-block', marginBottom: '16px', color: '#2563eb' }}>
        &larr; Back to Products
      </Link>
      <div
        style={{
          backgroundColor: '#ffffff',
          padding: '24px',
          borderRadius: '8px',
          border: '1px solid #d1d5db',
        }}
      >
        <h1 style={{ marginBottom: '8px' }}>{product.title}</h1>
        <p style={{ color: '#6b7280', marginBottom: '12px' }}>Category: {product.category}</p>
        <p style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '12px' }}>
          ${product.price.toFixed(2)}
        </p>
        <p style={{ marginBottom: '20px', lineHeight: '1.5' }}>{product.description}</p>

        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={() => dispatch(addToCart(product.id))}
            style={{
              backgroundColor: '#16a34a',
              color: '#ffffff',
              border: 'none',
              borderRadius: '6px',
              padding: '10px 18px',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            {cartItem ? `In Cart (${cartItem.qty}) - Add More` : 'Add to Cart'}
          </button>

          <button
            onClick={() => dispatch(toggleWish(product.id))}
            style={{
              backgroundColor: isWished ? '#ef4444' : '#2563eb',
              color: '#ffffff',
              border: 'none',
              borderRadius: '6px',
              padding: '10px 18px',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            {isWished ? 'Wished' : 'Wish'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default ProductDetailPage;
