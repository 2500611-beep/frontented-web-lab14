// Name: Laraib
// Reg No: 2500611

import React from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { selectLastOrder } from '../store/cartSlice';

function OrderConfirmationPage() {
  const order = useSelector(selectLastOrder);

  if (!order) {
    return (
      <div style={{ padding: '24px' }}>
        <h2>No recent order found</h2>
        <Link to="/" style={{ color: '#2563eb' }}>
          Back to Home
        </Link>
      </div>
    );
  }

  return (
    <div style={{ padding: '24px', maxWidth: '650px' }}>
      <div
        style={{
          backgroundColor: '#ffffff',
          padding: '28px',
          borderRadius: '8px',
          border: '1px solid #d1d5db',
        }}
      >
        <div
          style={{
            backgroundColor: '#dcfce7',
            color: '#166534',
            padding: '12px 16px',
            borderRadius: '6px',
            marginBottom: '18px',
            fontWeight: 'bold',
          }}
        >
          Order Placed Successfully!
        </div>

        <h2 style={{ marginBottom: '6px' }}>Order ID: {order.orderId}</h2>
        <p style={{ color: '#6b7280', fontSize: '14px', marginBottom: '16px' }}>
          Placed on: {order.date}
        </p>

        <div style={{ marginBottom: '16px', lineHeight: '1.6', fontSize: '15px' }}>
          <p>
            <strong>Customer:</strong> {order.customerName} ({order.email})
          </p>
          <p>
            <strong>Phone:</strong> {order.phone}
          </p>
          <p>
            <strong>Address:</strong> {order.address}
          </p>
          <p>
            <strong>Payment:</strong> {order.paymentMethod}
          </p>
        </div>

        <h3 style={{ fontSize: '16px', marginBottom: '8px' }}>Items Ordered</h3>
        <ul style={{ listStyle: 'none', padding: 0, marginBottom: '14px' }}>
          {order.items.map((item) => (
            <li
              key={item.id}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                padding: '6px 0',
                borderBottom: '1px solid #f3f4f6',
              }}
            >
              <span>
                {item.title} x {item.qty}
              </span>
              <span>${(item.price * item.qty).toFixed(2)}</span>
            </li>
          ))}
        </ul>

        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            fontWeight: 'bold',
            fontSize: '18px',
            marginBottom: '20px',
          }}
        >
          <span>Total Paid</span>
          <span>${order.total.toFixed(2)}</span>
        </div>

        <Link
          to="/"
          style={{
            display: 'inline-block',
            backgroundColor: '#2563eb',
            color: '#ffffff',
            padding: '10px 18px',
            borderRadius: '6px',
            textDecoration: 'none',
            fontWeight: 'bold',
          }}
        >
          Continue Shopping
        </Link>
      </div>
    </div>
  );
}

export default OrderConfirmationPage;
