// Name: Laraib
// Reg No: 2500611

import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import {
  selectCartItems,
  incrementQty,
  decrementQty,
  removeFromCart,
  clearCart,
} from '../store/cartSlice';
import products from '../data/products';

function CartPage() {
  const cartItems = useSelector(selectCartItems);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // Map cart items with full product details
  const detailedItems = cartItems
    .map((item) => {
      const product = products.find((p) => p.id === item.id);
      return product ? { ...product, qty: item.qty } : null;
    })
    .filter(Boolean);

  const totalAmount = detailedItems.reduce(
    (sum, item) => sum + item.price * item.qty,
    0
  );

  return (
    <div style={{ padding: '24px', maxWidth: '850px' }}>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '20px',
        }}
      >
        <h1>Shopping Cart</h1>
        {detailedItems.length > 0 && (
          <button
            onClick={() => dispatch(clearCart())}
            style={{
              padding: '8px 14px',
              backgroundColor: '#ef4444',
              color: '#ffffff',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
            }}
          >
            Clear Cart
          </button>
        )}
      </div>

      {detailedItems.length === 0 ? (
        <p style={{ color: '#6b7280' }}>
          Your cart is empty. <Link to="/">Continue shopping</Link>
        </p>
      ) : (
        <>
          <ul style={{ listStyle: 'none', padding: 0, marginBottom: '20px' }}>
            {detailedItems.map((item) => (
              <li
                key={item.id}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: '14px 16px',
                  marginBottom: '10px',
                  backgroundColor: '#ffffff',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  flexWrap: 'wrap',
                  gap: '10px',
                }}
              >
                <div>
                  <Link
                    to={`/product/${item.id}`}
                    style={{
                      fontSize: '17px',
                      fontWeight: 'bold',
                      color: '#2563eb',
                      textDecoration: 'none',
                    }}
                  >
                    {item.title}
                  </Link>
                  <p style={{ fontSize: '14px', color: '#4b5563', marginTop: '4px' }}>
                    ${item.price.toFixed(2)} each &bull; Subtotal:{' '}
                    <strong>${(item.price * item.qty).toFixed(2)}</strong>
                  </p>
                </div>

                {/* Quantity controls and remove button */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <button
                    onClick={() => dispatch(decrementQty(item.id))}
                    style={{
                      width: '30px',
                      height: '30px',
                      borderRadius: '6px',
                      border: '1px solid #d1d5db',
                      backgroundColor: '#f3f4f6',
                      cursor: 'pointer',
                      fontWeight: 'bold',
                    }}
                  >
                    -
                  </button>
                  <span style={{ minWidth: '24px', textAlign: 'center', fontWeight: 'bold' }}>
                    {item.qty}
                  </span>
                  <button
                    onClick={() => dispatch(incrementQty(item.id))}
                    style={{
                      width: '30px',
                      height: '30px',
                      borderRadius: '6px',
                      border: '1px solid #d1d5db',
                      backgroundColor: '#f3f4f6',
                      cursor: 'pointer',
                      fontWeight: 'bold',
                    }}
                  >
                    +
                  </button>
                  <button
                    onClick={() => dispatch(removeFromCart(item.id))}
                    style={{
                      marginLeft: '8px',
                      backgroundColor: 'transparent',
                      border: '1px solid #ef4444',
                      color: '#ef4444',
                      padding: '5px 10px',
                      borderRadius: '6px',
                      cursor: 'pointer',
                    }}
                  >
                    Remove
                  </button>
                </div>
              </li>
            ))}
          </ul>

          {/* Total and Proceed to Checkout */}
          <div
            style={{
              backgroundColor: '#ffffff',
              padding: '18px 20px',
              borderRadius: '8px',
              border: '1px solid #d1d5db',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <div style={{ fontSize: '20px', fontWeight: 'bold' }}>
              Total: ${totalAmount.toFixed(2)}
            </div>
            <button
              onClick={() => navigate('/checkout')}
              style={{
                backgroundColor: '#2563eb',
                color: '#ffffff',
                border: 'none',
                borderRadius: '6px',
                padding: '10px 20px',
                fontSize: '15px',
                fontWeight: 'bold',
                cursor: 'pointer',
              }}
            >
              Proceed to Checkout &rarr;
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default CartPage;
