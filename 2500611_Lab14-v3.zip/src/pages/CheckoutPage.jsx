// Name: Laraib
// Reg No: 2500611

import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { selectCartItems, placeOrder } from '../store/cartSlice';
import products from '../data/products';

function CheckoutPage() {
  const cartItems = useSelector(selectCartItems);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // Controlled form inputs
  const [customerName, setCustomerName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('Cash on Delivery');
  const [agreedTerms, setAgreedTerms] = useState(false);

  // Field-level validation errors
  const [errors, setErrors] = useState({});

  const detailedItems = cartItems
    .map((item) => {
      const product = products.find((p) => p.id === item.id);
      return product ? { ...product, qty: item.qty } : null;
    })
    .filter(Boolean);

  const totalAmount = detailedItems.reduce(
    (sum, item) => sum + item.price * item.qty,
    0
  );

  if (detailedItems.length === 0) {
    return (
      <div style={{ padding: '24px' }}>
        <h2>No items to checkout</h2>
        <p style={{ marginTop: '8px', color: '#6b7280' }}>
          Add some products first. <Link to="/">Go to Home</Link>
        </p>
      </div>
    );
  }

  // Validate every input field
  const validateForm = () => {
    const newErrors = {};

    if (!customerName.trim()) {
      newErrors.customerName = 'Full name is required.';
    } else if (customerName.trim().length < 3) {
      newErrors.customerName = 'Name must be at least 3 characters.';
    } else if (!/^[a-zA-Z\s]+$/.test(customerName.trim())) {
      newErrors.customerName = 'Name should only contain letters.';
    }

    if (!email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      newErrors.email = 'Please enter a valid email address.';
    }

    if (!phone.trim()) {
      newErrors.phone = 'Phone number is required.';
    } else if (!/^03\d{2}-?\d{7}$/.test(phone.trim())) {
      newErrors.phone = 'Enter a valid phone number (e.g., 0300-1234567).';
    }

    if (!address.trim()) {
      newErrors.address = 'Delivery address is required.';
    } else if (address.trim().length < 10) {
      newErrors.address = 'Please enter a complete address (min 10 characters).';
    }

    if (!paymentMethod) {
      newErrors.paymentMethod = 'Please select a payment method.';
    }

    if (!agreedTerms) {
      newErrors.agreedTerms = 'You must agree to the terms & conditions before placing the order.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    const orderSummary = {
      orderId: 'ORD-' + Math.floor(100000 + Math.random() * 900000),
      date: new Date().toLocaleString(),
      customerName: customerName.trim(),
      email: email.trim(),
      phone: phone.trim(),
      address: address.trim(),
      paymentMethod,
      items: detailedItems,
      total: totalAmount,
    };

    dispatch(placeOrder(orderSummary));
    navigate('/order-confirmation');
  };

  const getInputStyle = (hasError) => ({
    width: '100%',
    padding: '9px 12px',
    border: hasError ? '1px solid #ef4444' : '1px solid #d1d5db',
    borderRadius: '6px',
    marginTop: '4px',
  });

  const errorTextStyle = {
    color: '#ef4444',
    fontSize: '12px',
    marginTop: '4px',
  };

  const paymentOptions = [
    'Cash on Delivery',
    'Credit / Debit Card',
    'Bank Transfer',
  ];

  return (
    <div style={{ padding: '24px', maxWidth: '850px' }}>
      <Link to="/cart" style={{ color: '#2563eb', textDecoration: 'none' }}>
        &larr; Back to Cart
      </Link>
      <h1 style={{ margin: '12px 0 20px' }}>Checkout</h1>

      <div style={{ display: 'flex', gap: '24px', flexWrap: 'wrap' }}>
        {/* Shipping Form */}
        <form
          onSubmit={handleSubmit}
          noValidate
          style={{
            flex: '1 1 420px',
            backgroundColor: '#ffffff',
            padding: '20px',
            borderRadius: '8px',
            border: '1px solid #d1d5db',
          }}
        >
          <h2 style={{ fontSize: '18px', marginBottom: '14px' }}>Shipping Details</h2>

          {/* Full Name */}
          <div style={{ marginBottom: '14px' }}>
            <label>Full Name</label>
            <input
              type="text"
              placeholder="Enter your name"
              value={customerName}
              onChange={(e) => {
                setCustomerName(e.target.value);
                if (errors.customerName) setErrors({ ...errors, customerName: '' });
              }}
              style={getInputStyle(errors.customerName)}
            />
            {errors.customerName && <p style={errorTextStyle}>{errors.customerName}</p>}
          </div>

          {/* Email Address */}
          <div style={{ marginBottom: '14px' }}>
            <label>Email Address</label>
            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (errors.email) setErrors({ ...errors, email: '' });
              }}
              style={getInputStyle(errors.email)}
            />
            {errors.email && <p style={errorTextStyle}>{errors.email}</p>}
          </div>

          {/* Phone Number */}
          <div style={{ marginBottom: '14px' }}>
            <label>Phone Number</label>
            <input
              type="tel"
              placeholder="03XX-XXXXXXX"
              value={phone}
              onChange={(e) => {
                setPhone(e.target.value);
                if (errors.phone) setErrors({ ...errors, phone: '' });
              }}
              style={getInputStyle(errors.phone)}
            />
            {errors.phone && <p style={errorTextStyle}>{errors.phone}</p>}
          </div>

          {/* Delivery Address */}
          <div style={{ marginBottom: '14px' }}>
            <label>Delivery Address</label>
            <textarea
              rows="3"
              placeholder="House #, Street, City"
              value={address}
              onChange={(e) => {
                setAddress(e.target.value);
                if (errors.address) setErrors({ ...errors, address: '' });
              }}
              style={getInputStyle(errors.address)}
            />
            {errors.address && <p style={errorTextStyle}>{errors.address}</p>}
          </div>

          {/* Payment Method Radio Buttons */}
          <div style={{ marginBottom: '16px' }}>
            <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500' }}>
              Payment Method
            </label>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {paymentOptions.map((option) => (
                <label
                  key={option}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    cursor: 'pointer',
                    padding: '8px 10px',
                    border: paymentMethod === option ? '1px solid #2563eb' : '1px solid #e5e7eb',
                    borderRadius: '6px',
                    backgroundColor: paymentMethod === option ? '#eff6ff' : '#ffffff',
                  }}
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    value={option}
                    checked={paymentMethod === option}
                    onChange={(e) => {
                      setPaymentMethod(e.target.value);
                      if (errors.paymentMethod) setErrors({ ...errors, paymentMethod: '' });
                    }}
                  />
                  <span>{option}</span>
                </label>
              ))}
            </div>
            {errors.paymentMethod && <p style={errorTextStyle}>{errors.paymentMethod}</p>}
          </div>

          {/* Terms & Conditions Checkbox */}
          <div style={{ marginBottom: '18px' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={agreedTerms}
                onChange={(e) => {
                  setAgreedTerms(e.target.checked);
                  if (errors.agreedTerms) setErrors({ ...errors, agreedTerms: '' });
                }}
              />
              <span style={{ fontSize: '14px' }}>
                I confirm my order details and agree to the Terms &amp; Conditions.
              </span>
            </label>
            {errors.agreedTerms && <p style={errorTextStyle}>{errors.agreedTerms}</p>}
          </div>

          <button
            type="submit"
            style={{
              width: '100%',
              backgroundColor: '#16a34a',
              color: '#ffffff',
              border: 'none',
              borderRadius: '6px',
              padding: '12px',
              fontSize: '16px',
              fontWeight: 'bold',
              cursor: 'pointer',
            }}
          >
            Place Order (${totalAmount.toFixed(2)})
          </button>
        </form>

        {/* Order Summary Box */}
        <div
          style={{
            flex: '1 1 280px',
            backgroundColor: '#ffffff',
            padding: '20px',
            borderRadius: '8px',
            border: '1px solid #d1d5db',
            height: 'fit-content',
          }}
        >
          <h2 style={{ fontSize: '18px', marginBottom: '14px' }}>Order Summary</h2>
          {detailedItems.map((item) => (
            <div
              key={item.id}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                marginBottom: '8px',
                fontSize: '14px',
              }}
            >
              <span>
                {item.title} x {item.qty}
              </span>
              <span>${(item.price * item.qty).toFixed(2)}</span>
            </div>
          ))}
          <hr style={{ margin: '12px 0', borderColor: '#e5e7eb' }} />
          <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold' }}>
            <span>Grand Total</span>
            <span>${totalAmount.toFixed(2)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CheckoutPage;
