// Name: Laraib
// Reg No: 2500611

import React from 'react';
import { Link } from 'react-router-dom';

function NotFoundPage() {
  return (
    <div style={{ padding: '48px 24px', textAlign: 'center' }}>
      <h1 style={{ fontSize: '48px', marginBottom: '8px' }}>404</h1>
      <p style={{ fontSize: '18px', color: '#6b7280', marginBottom: '20px' }}>
        Page not found.
      </p>
      <Link to="/" style={{ color: '#2563eb', fontWeight: 'bold' }}>
        Go back to Home
      </Link>
    </div>
  );
}

export default NotFoundPage;
