// Name: Laraib
// Reg No: 2500611

import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { selectWishIds, clearWish, toggleWish } from '../store/wishlistSlice';
import { addToCart } from '../store/cartSlice';
import products from '../data/products';

function WishlistPage() {
  const wishIds = useSelector(selectWishIds);
  const dispatch = useDispatch();

  // Filter products whose IDs exist in the Redux wishlist state
  const wishedProducts = products.filter((product) =>
    wishIds.includes(product.id)
  );

  return (
    <div style={{ padding: '24px', maxWidth: '800px' }}>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '20px',
        }}
      >
        <h1>My Wishlist ({wishedProducts.length})</h1>

        {wishedProducts.length > 0 && (
          <button
            onClick={() => dispatch(clearWish())}
            style={{
              padding: '8px 14px',
              backgroundColor: '#ef4444',
              color: '#ffffff',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
            }}
          >
            Clear Wishlist
          </button>
        )}
      </div>

      {wishedProducts.length === 0 ? (
        <p style={{ color: '#6b7280' }}>
          Your wishlist is empty. <Link to="/">Browse products</Link>
        </p>
      ) : (
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {wishedProducts.map((product) => (
            <li
              key={product.id}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '14px 16px',
                marginBottom: '10px',
                backgroundColor: '#ffffff',
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
              }}
            >
              <div>
                {/* Link to individual product details page */}
                <Link
                  to={`/product/${product.id}`}
                  style={{
                    fontSize: '18px',
                    fontWeight: 'bold',
                    color: '#2563eb',
                    textDecoration: 'none',
                  }}
                >
                  {product.title}
                </Link>
                <span style={{ marginLeft: '12px', color: '#4b5563' }}>
                  ${product.price.toFixed(2)}
                </span>
              </div>

              <div style={{ display: 'flex', gap: '8px' }}>
                <button
                  onClick={() => dispatch(addToCart(product.id))}
                  style={{
                    backgroundColor: '#16a34a',
                    border: 'none',
                    color: '#ffffff',
                    padding: '5px 12px',
                    borderRadius: '6px',
                    cursor: 'pointer',
                  }}
                >
                  Add to Cart
                </button>
                <button
                  onClick={() => dispatch(toggleWish(product.id))}
                  style={{
                    backgroundColor: 'transparent',
                    border: '1px solid #ef4444',
                    color: '#ef4444',
                    padding: '5px 10px',
                    borderRadius: '6px',
                    cursor: 'pointer',
                  }}
                >
                  Remove
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default WishlistPage;
