// Name: Laraib
// Reg No: 2500611

import React from 'react';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { toggleWish, selectWishIds } from '../store/wishlistSlice';
import { addToCart, selectCartItems } from '../store/cartSlice';

function ProductCard({ product }) {
  const dispatch = useDispatch();
  const wishIds = useSelector(selectWishIds);
  const cartItems = useSelector(selectCartItems);

  // Check whether the current product is in the wishlist
  const isWished = wishIds.includes(product.id);
  const cartItem = cartItems.find((i) => i.id === product.id);

  return (
    <div
      style={{
        border: '1px solid #d1d5db',
        borderRadius: '8px',
        padding: '16px',
        width: '275px',
        backgroundColor: '#ffffff',
        boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
      }}
    >
      <div>
        <h3 style={{ marginBottom: '8px', fontSize: '18px' }}>{product.title}</h3>
        <p style={{ color: '#6b7280', fontSize: '14px', marginBottom: '4px' }}>
          Category: {product.category}
        </p>
        <p style={{ fontWeight: 'bold', marginBottom: '14px' }}>
          Price: ${product.price.toFixed(2)}
        </p>
      </div>

      <div>
        <div style={{ marginBottom: '10px' }}>
          <Link
            to={`/product/${product.id}`}
            style={{ color: '#2563eb', textDecoration: 'none', fontSize: '14px' }}
          >
            View Details
          </Link>
        </div>

        <div style={{ display: 'flex', gap: '8px' }}>
          {/* Add to Cart button */}
          <button
            onClick={() => dispatch(addToCart(product.id))}
            style={{
              flex: 1,
              backgroundColor: '#16a34a',
              color: '#ffffff',
              border: 'none',
              borderRadius: '6px',
              padding: '7px 10px',
              cursor: 'pointer',
              fontWeight: '500',
              fontSize: '13px',
            }}
          >
            {cartItem ? `Add More (${cartItem.qty})` : 'Add to Cart'}
          </button>

          {/* Toggle Wish / Wished button */}
          <button
            onClick={() => dispatch(toggleWish(product.id))}
            style={{
              backgroundColor: isWished ? '#ef4444' : '#e5e7eb',
              color: isWished ? '#ffffff' : '#111827',
              border: 'none',
              borderRadius: '6px',
              padding: '7px 12px',
              cursor: 'pointer',
              fontWeight: '500',
              fontSize: '13px',
            }}
          >
            {isWished ? 'Wished' : 'Wish'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default ProductCard;
