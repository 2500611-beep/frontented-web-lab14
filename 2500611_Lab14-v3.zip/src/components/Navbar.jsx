// Name: Laraib
// Reg No: 2500611

import React from 'react';
import { NavLink } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { selectWishIds } from '../store/wishlistSlice';
import { selectCartCount } from '../store/cartSlice';

function Navbar() {
  const wishIds = useSelector(selectWishIds);
  const cartCount = useSelector(selectCartCount);

  // Highlight active route link
  const navLinkStyle = ({ isActive }) => ({
    fontWeight: isActive ? 'bold' : 'normal',
    color: isActive ? '#2563eb' : '#374151',
    textDecoration: isActive ? 'underline' : 'none',
    marginRight: '20px',
    fontSize: '16px',
    display: 'inline-flex',
    alignItems: 'center',
  });

  const badgeStyle = (bg) => ({
    backgroundColor: bg,
    color: '#ffffff',
    borderRadius: '9999px',
    padding: '2px 8px',
    fontSize: '12px',
    marginLeft: '6px',
    fontWeight: 'bold',
  });

  return (
    <nav
      style={{
        padding: '16px 24px',
        backgroundColor: '#ffffff',
        borderBottom: '1px solid #e5e7eb',
        display: 'flex',
        alignItems: 'center',
      }}
    >
      <NavLink to="/" style={navLinkStyle}>
        Home
      </NavLink>

      {/* Wishlist NavLink with dynamic count badge */}
      <NavLink to="/wishlist" style={navLinkStyle}>
        Wishlist
        <span style={badgeStyle('#2563eb')}>{wishIds.length}</span>
      </NavLink>

      {/* Cart NavLink with dynamic item count badge */}
      <NavLink to="/cart" style={navLinkStyle}>
        Cart
        <span style={badgeStyle('#16a34a')}>{cartCount}</span>
      </NavLink>
    </nav>
  );
}

export default Navbar;
