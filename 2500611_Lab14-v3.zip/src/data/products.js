// Name: Laraib
// Reg No: 2500611

const products = [
  {
    id: 1,
    title: 'React Handbook',
    category: 'Books',
    price: 29.99,
    description: 'A complete guide to modern React, hooks, Redux Toolkit, and React Router.',
  },
  {
    id: 2,
    title: 'JavaScript: The Good Parts',
    category: 'Books',
    price: 24.50,
    description: 'Essential concepts and best practices for writing clean JavaScript.',
  },
  {
    id: 3,
    title: 'Mechanical Keyboard',
    category: 'Electronics',
    price: 89.99,
    description: 'Tactile mechanical keyboard with RGB backlight for developers.',
  },
  {
    id: 4,
    title: 'Wireless Mouse',
    category: 'Electronics',
    price: 39.99,
    description: 'Ergonomic wireless mouse with adjustable DPI.',
  },
  {
    id: 5,
    title: 'Developer Hoodie',
    category: 'Clothing',
    price: 49.99,
    description: 'Comfortable cotton hoodie for late-night coding sessions.',
  },
];

export default products;
