// Name: Laraib
// Reg No: 2500611

import { createSlice } from '@reduxjs/toolkit';

// Cart slice to manage cart items ({ id, qty }) and placed orders
const cartSlice = createSlice({
  name: 'cart',
  initialState: {
    items: [], // [{ id: 1, qty: 2 }]
    lastOrder: null,
  },
  reducers: {
    // Add product to cart or increment quantity
    addToCart(state, action) {
      const id = action.payload;
      const existing = state.items.find((item) => item.id === id);
      if (existing) {
        existing.qty += 1;
      } else {
        state.items.push({ id, qty: 1 });
      }
    },
    // Increment item quantity
    incrementQty(state, action) {
      const item = state.items.find((i) => i.id === action.payload);
      if (item) item.qty += 1;
    },
    // Decrement item quantity or remove if qty reaches 0
    decrementQty(state, action) {
      const id = action.payload;
      const item = state.items.find((i) => i.id === id);
      if (item) {
        if (item.qty > 1) {
          item.qty -= 1;
        } else {
          state.items = state.items.filter((i) => i.id !== id);
        }
      }
    },
    // Remove item completely from cart
    removeFromCart(state, action) {
      state.items = state.items.filter((i) => i.id !== action.payload);
    },
    // Clear all items in cart
    clearCart(state) {
      state.items = [];
    },
    // Save placed order details and clear cart
    placeOrder(state, action) {
      state.lastOrder = action.payload;
      state.items = [];
    },
  },
});

export const {
  addToCart,
  incrementQty,
  decrementQty,
  removeFromCart,
  clearCart,
  placeOrder,
} = cartSlice.actions;

export const selectCartItems = (state) => state.cart.items;
export const selectCartCount = (state) =>
  state.cart.items.reduce((sum, item) => sum + item.qty, 0);
export const selectLastOrder = (state) => state.cart.lastOrder;

export default cartSlice.reducer;
