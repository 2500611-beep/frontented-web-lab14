// Name: Laraib
// Reg No: 2500611

import { createSlice } from '@reduxjs/toolkit';

// Wishlist slice to manage wished product IDs
const wishlistSlice = createSlice({
  name: 'wishlist',
  initialState: { ids: [] },
  reducers: {
    // Add product ID if missing, remove if already present
    toggleWish(state, action) {
      const id = action.payload;
      if (state.ids.includes(id)) {
        state.ids = state.ids.filter((itemId) => itemId !== id);
      } else {
        state.ids.push(id);
      }
    },
    // Clear all items from the wishlist
    clearWish(state) {
      state.ids = [];
    },
  },
});

export const { toggleWish, clearWish } = wishlistSlice.actions;

// Selector to retrieve wished product IDs from the store
export const selectWishIds = (state) => state.wishlist.ids;

export default wishlistSlice.reducer;
